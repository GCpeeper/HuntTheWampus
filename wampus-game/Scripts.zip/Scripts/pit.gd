# Answer a trivia/riddle/math question to get out. Need 2 correct to survive
extends Control

# Different onreadys mostly referring to the aspects of the cutscene
@onready var announcement = $Label
@onready var announcement2 = $Label2
@onready var question = $Question
@onready var answers = $Answers
@onready var player = get_parent().player
@onready var timer = $"../Timer"
@onready var riddleTimer = $"../Riddle_Timer"
@onready var timerBar = $ProgressBar
@onready var animation_player = $"../AnimationPlayer"
@onready var bubble = $"../TileMapLayer2"
@onready var roaring = $"../Roar"
var step = 0
var riddleList = []
# The riddles/math questions/trivia. [0] is the question, [1][2][3] and [4] are the answers, and [5] is the correct answer (referring to the place in the array)
var riddle1 = ["What has roots that nobody sees, is taller than trees, up, up it goes, and yet never grows?", "A tall tree.", "A mountain", "A shadow", "The Parthenon", 2]
var riddle2 = ["There is a right triangle with sides A, B, and C. Side AB is 5 feet, angle A is 45, and angle B is 90. What is the area of the triangle?", "56 feet squared", "25 feet squared", "12.5 feet squared", "25.5 feet squared", 3]
var riddle3 = ["I look at you whenever you look at me. What am I?", "A reflection", "A photo", "Glasses", "Letters", 1]
var riddle4 = ["When was the Parthenon completed?", "431 BC", "432 BC", "433 BC", "259 BC", 2]
var riddle5 = ["What is the only land mammal that can't jump?", "Whale", "Deer", "Goat", "Elephant", 4]
var riddle6 = ["Who made the original Hunt the Wumpus?","Jimmy Donaldson","Gregory Donaldson","Gregory Yob", "Jimmy Yob", 3]
var riddle7 = ["How many peanuts does it take to make a jar of peanut butter?", "540", "320", "342", "200", 1]
var riddle8 = ["Using Archimedes' Principle, if the bouyant force on an object is 10 newtons, what is the volume of the object (using 9.8 meters squared)?", "2.3 liters","1.56 liters","1.02 liters", "3 liters",3]
var riddle9 = ["There is one father with 12 children, who each have 30 or so of their own. They are all immortal and yet all fade away. What is the father?", "A guy with a lot of kids", "A year", "A grandfather", "A spider", 2]
var riddle10 = ["It's dark but comes from something bright. It flies without wings. Those who see it sometimes cry. It can vanish into thin air. What is it?", "B-2 Stealth Bomber", "A ghost", "Smoke", "Death", 3]
var riddle11 = ["What is the equatorial circumference of the Earth?", "50,001 kilometers", "70,234 kilometers", "40,075 kilometers", "24,901 kilometers", 3]
var answer: int
var buttonList : Dictionary
var riddleChoice: int
var tries = 3
var correctTries = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	player.taking_input = false
	announcement.hide()
	announcement2.hide()
	bubble.visible = false
	question.hide()
	answers.hide()
	timerBar.value = 15
	riddleList = [riddle1, riddle2, riddle3, riddle4,riddle5,riddle6,riddle7,riddle8,riddle9,riddle10,riddle11] # sets up the riddle list
	buttonList = {$Buttons/A: 1,$Buttons/B: 2,$Buttons/C: 3,$Buttons/D:4}
	for i in buttonList.keys():
		i.pressed.connect(some_button_pressed.bind(i))

# Pressed a button
func some_button_pressed(button):
	player.coins -= 1
	if buttonList.get(button) == (riddleList[riddleChoice])[5]:
		#print("yeah")
		success()
	else:
		#print("nah")
		failure()

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	# They said to make it keyboard functional so here this is
	if $Buttons.visible:
		if Input.is_action_just_pressed("A"):
			some_button_pressed($Buttons/A)
		if Input.is_action_just_pressed("B"):
			some_button_pressed($Buttons/B)
		if Input.is_action_just_pressed("C"):
			some_button_pressed($Buttons/C)
		if Input.is_action_just_pressed("D"):
			some_button_pressed($Buttons/D)
	if step == 0:
		announcement.show()
		bubble.visible = true
		$"../Pit Wampus".visible = true
		animation_player.play("talking")
		roaring.play()
		announcement.text = "You fell down the Pit!"
		announcement2.show()
		timer.start()
		step += 1
	if timerBar.visible == true:
		timerBar.value = riddleTimer.time_left

# Correct answer
func success():
	animation_player.play("talking")
	roaring.play()
	announcement.show()
	bubble.show()
	announcement.text = "Good job!"
	question.hide()
	answers.hide()
	$Buttons.hide()
	timerBar.hide()
	correctTries += 1
	tries -= 1
	if tries > 0 and correctTries != 2:
		timer.start()
	else: # Determining if you still lost or if you won
		if correctTries == 2:
			await get_tree().create_timer(1.0).timeout
			announcement.text = "You survive!!!" # yippie
			await get_tree().create_timer(3.0).timeout
		else:
			await get_tree().create_timer(1.0).timeout
			announcement.text = "You lose!!!"
			await get_tree().create_timer(3.0).timeout
			get_tree().change_scene_to_file("res://Scenes/main_menu.tscn") # die
		# Setting everything back to normal and back to normal room functionality
		player.taking_input = true
		get_parent().get_parent().doneWithHazard = true
		get_parent().get_parent().enterRoom(4)
		get_parent().queue_free()

# wrong answer
func failure():
	animation_player.play("talking")
	roaring.play()
	bubble.show()
	announcement.show()
	announcement.text = "Wrong answer!"
	question.hide()
	answers.hide()
	$Buttons.hide()
	timerBar.hide()
	tries -= 1
	if tries > 0:
		timer.start()
	else: # You die
		await get_tree().create_timer(1.0).timeout
		announcement.text = "You lose!!!"
		await get_tree().create_timer(3.0).timeout
		get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")

# Talking timer timed out to start the riddle system
func _on_timer_timeout() -> void:
	bubble.visible = false
	animation_player.play("idle")
	#print("tries" + str(tries))
	#print("correct tries" + str(correctTries))
	announcement.hide()
	announcement2.hide()
	question.show()
	answers.show()
	$Buttons.show()
	timerBar.show()
	riddleTimer.start()
	riddleChoice = randi_range(0,9) # Picking a random riddle
	#print(riddleChoice)
	question.text = (riddleList[riddleChoice])[0]
	answers.text = ": " + (riddleList[riddleChoice])[1] + "\n: " + (riddleList[riddleChoice])[2] + "\n: " + (riddleList[riddleChoice])[3] + "\n: " + (riddleList[riddleChoice])[4]


func _on_pressed() -> void:
	pass # Replace with function body.

# Ran out of time on the riddle!
func _on_riddle_timer_timeout() -> void:
	animation_player.play("talking")
	roaring.play()
	bubble.visible = true
	announcement.show()
	announcement.text = "You ran out of time!"
	question.hide()
	answers.hide()
	$Buttons.hide()
	timerBar.hide()
	await get_tree().create_timer(3.0).timeout
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")
